import React, { Component } from 'react';
import Sidebar from "../component/sidebar/Sidebar"
class Home extends Component {
    render() {
        return (
            <div>
                <Sidebar></Sidebar>
            </div>
        );
    }
}

export default Home;